plotTopDrugScores <-
function(scores, drugs, figName = "", srt = 60, 
						cut2Max = FALSE, mar = c(13,4,2,0))
{
## cut2Max, Figure lower bound of ylim will be the maximum of the 
## negative scores if it is TRUE, 0 if it is FALSE.
	if (figName == "") figName <- paste0("Top_", length(drugs), "_drugs")
	
	pdf(paste0(figName, ".pdf"), width = 9, height = 6)
	if (cut2Max) {
		ylim = c(max(scores)*0.96, min(scores))
	} else {
		ylim = c(0, min(scores))
	}
	par(mar = mar) # mar for setting margins
	x <- barplot(scores, ylab = "z-score", cex.lab = 1.5, col = "greenyellow", 
				space = 1, ylim = ylim, cex.axis = 1.5, xpd = FALSE)
				
	text(cex=1.5, y = ifelse(cut2Max, ylim[1]*0.97, min(abs(scores))*0.03), 
		x=x+0.7, drugs, xpd=TRUE, srt=srt, pos=2)
	dev.off()
}
