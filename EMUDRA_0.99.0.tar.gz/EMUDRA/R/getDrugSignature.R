getDrugSignature <-
function(drugName, instanceDEGs, productionTreated, 
							CombnUpDn = FALSE) 
{	
	drugInst <- which(productionTreated[, 3] == drugName)
	if (length(drugInst) == 1) {
		drugUpGenes <- instanceDEGs[[drugInst]][[1]]
		drugDnGenes <- instanceDEGs[[drugInst]][[2]]
	} else if (length(drugInst) > 1) {
		drugUpGenes <- NULL
		drugDnGenes <- NULL
		for (j in 1:length(drugInst)) {
			drugUpGenes <- c(drugUpGenes, instanceDEGs[[drugInst[j]]][[1]])
			drugDnGenes <- c(drugDnGenes, instanceDEGs[[drugInst[j]]][[2]])
		}
	} else stop(paste0("The drug ", drugName, " was not tested in the CMap 
				production batches."))
	if(CombnUpDn) return(unique(c(drugUpGenes, drugDnGenes)))
	else return(list(drugUpGenes, drugDnGenes))
}
