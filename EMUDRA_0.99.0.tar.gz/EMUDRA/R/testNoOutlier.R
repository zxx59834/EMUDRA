testNoOutlier <-
function(scores, fold = 1.5) {
	scores <- excludeOutliers(scores, fold)
	test.norm(c(scores, -scores))
}
