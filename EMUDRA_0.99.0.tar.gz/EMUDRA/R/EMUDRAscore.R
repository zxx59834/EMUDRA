EMUDRAscore <-
function(upGenes, dnGenes, 
					logFCMatrix, eX500logFC, EWlogFC, 
					productionTreated, 
					instScores = FALSE, 
					CL = "all") 
{
	# upGenes and dnGenes should be two columns with gene and logFC
	# instScores: should output scores at instance level or not, FALSE means at 
	# drug level
	# CL: cell line, currently could be one of "MCF7", "PC3", " HL60", could be
	# more cell lines of the LINCS data set in the future.

	if (CL != "all") {
		CLInstances <- which(is.element(productionTreated$cell2, CL))
		if (length(CLInstances) == 0) stop(paste("There is no", CL, "instance in the CMap"))
		logFCMatrix <- logFCMatrix[, CLInstances]
		eX500logFC <- eX500logFC[, CLInstances]
		EWlogFC <- EWlogFC[, CLInstances]
		productionTreated <- productionTreated[CLInstances, ]
	}
	CosScores <- XCosine(logFCMatrix, upGenes, dnGenes)
	XCorScores <- XCorrelation(eX500logFC, upGenes, dnGenes)
	XSpeScores <- suppressWarnings(XCorrelation(eX500logFC, upGenes, dnGenes, 
				"spearman"))
	EWCosScores <- XCosine(EWlogFC, upGenes, dnGenes)
	XSpeScores[is.na(XSpeScores)] <- 0L
	XCorScores[is.na(XCorScores)] <- 0L	
	CosScores[is.na(CosScores)] <- 0L
	EWCosScores[is.na(EWCosScores)] <- 0L
	CombnZsc <- combn4Zscores(CosScores, XCorScores, XSpeScores, EWCosScores)
	if (!instScores) {
		drugZScore <- drug.scores(productionTreated[, 3], cbind(CombnZsc, CosScores, 
					XCorScores, XSpeScores, EWCosScores))
		colnames(drugZScore) <- c("compound", "Normalized.Score", "Cosine", "XCor", "XSpe", "EWCos")
		drugZScore[order(drugZScore[, 2]), ]
	} else {
		output <- cbind(productionTreated[, c(1,2,3,5,7)], CombnZsc, CosScores, 
					XCorScores, XSpeScores, EWCosScores)
		colnames(output) <- c("instance_id", "batch_id", "compound", "concentration", 
						"cell line", "Normalized.Score", "Cosine", "XCor", "XSpe", "EWCos")
		output[order(output[, 6]), ]
	}
	
}
