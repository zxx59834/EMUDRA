combn4Zscores <-
function(CosScores, XCorScores, XSpeScores, EWCosScores = NULL) 
{	
	stopifnot(length(CosScores) == length(XCorScores), length(XSpeScores) == length(XCorScores))
	CosineZsc <- score2ZscoreTogether(CosScores)
	XCorZsc <- score2ZscoreTogether(XCorScores)
	XSpeZsc <- score2ZscoreTogether(XSpeScores)
	if (is.null(EWCosScores)) {
		return(CosineZsc + XCorZsc + XSpeZsc)
	} else {
		stopifnot(length(XCorScores) == length(EWCosScores))
		EWCosZsc <- score2ZscoreTogether(EWCosScores)
		return(CosineZsc + XCorZsc + XSpeZsc + EWCosZsc)
	}
}
