sigmoid <-
function(x, a = 1, b = 0) {

    stopifnot(is.numeric(a), is.numeric(b))

    1 / (1 + exp(-a*(x-b)))
}
