pValWeight <-
function(logFC, expVal, k = 1, a = 4, b = 1, gm = 6.745805) {

	stopifnot(length(logFC) == length(expVal))
	y <- sigmoid(expVal, a, gm*k)
	
	logFC^b*y
}
