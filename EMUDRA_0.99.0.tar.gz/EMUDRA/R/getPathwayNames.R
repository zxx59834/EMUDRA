getPathwayNames <-
function(ontology = "BP")
{
	## ontology could be "BP" for Gene Ontology (GO) Biological Process, "CC" 
	## for GO Cell Component, "MF" for GO Molecular Function, 
	## "KEGG" for KEGG pathway, and "" for all GO terms
	# respos <- "http://cran.us.r-project.org"
	if (ontology == "all") {
		## Loading the GO structure or KEGG pathway data
		# require("GO.db") || install.packages(organism, repos = respos) || 
				# stop("package GO.db is required")
		conn <- get("GO_dbconn")()
		.sql <- "select distinct go_id goid,term name from go_term"
	} else if (toupper(ontology) == "KEGG") {
		## Loading the KEGG pathway data
		# require("KEGG.db") || install.packages(organism, repos = respos) || 
				# stop("package KEGG.db is required")
		conn <- get("KEGG_dbconn")()
		.sql <- paste("select distinct path_id,path_name from pathway2name")
	} else {
		# require("GO.db") || install.packages(organism, repos = respos) || 
				# stop("package GO.db is required")
		conn <- get("GO_dbconn")()
		.sql <- paste("select distinct go_id goid,term name from go_term where 
				ontology='", toupper(ontology), "'", sep="")
	}
	dbGetQuery(conn, .sql)
}
