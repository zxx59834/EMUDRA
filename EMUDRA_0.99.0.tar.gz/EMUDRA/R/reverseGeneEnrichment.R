reverseGeneEnrichment <-
function(UpGenes, DnGenes, 
						drugs, 
						instanceDEGs, 
						productionTreated, 
						refGenes, 
						fdrMethod = "BH", 
						fdrth = 0.05, 
						ontology = "BP", 
						species = "Hs", 
						separate = FALSE) 
{
	## fdrMethod could be "BH", "BY", "bonferroni" and "none"
	## refGenes (reference gene; background) should have 2 identifiers, geneid 
	# (the first column) and symbol (the second column)
	## 
	## separate TRUE means analyse up-regulated genes and down-regulated genes 
	## separately drugs 
	
	## fdrMethod is p-value correction method, could be "BH", "BY", "bonferroni" 
	## or "none"; fdrth (0, 1], is the threshold to be used to cut off significant 
	## functions (GO terms, KEGG parhways)ontology could be "BP", "CC", "MF", "all" 
	## (for all GO terms) or "KEGG"; 
	##
	## species: Gene Ontology enrichment analysis can be applied to the following 
	## organisms: Anopheles ”org.Ag.eg.db” (Ag), Arabidopsis, "org.At.tair.db" 
	## (At), Bovine ”org.Bt.eg.db” (Bt), Canine ”org.Cf.eg.db” (Cf), Chicken 
	## ”org.Gg.eg.db” (Gg), Chimp ”org.Pt.eg.db” (Pt), E coli strain K12 
	## ”org.EcK12.eg.db” (EcK12), E coli strain Sakai”org.EcSakai.eg.db” (EcSakai), 
	## Fly ”org.Dm.eg.db” (Dm), Human ”org.Hs.eg.db” (Hs, the default), 
	## Mouse ”org.Mm.eg.db” (Mm), Pig ”org.Ss.eg.db” (Ss), Rat ”org.Rn.eg.db” (Rn), 
	## Rhesus ”org.Mmu.eg.db” (Mmu), Streptomyces coelicolor ”org.Sco.eg.db” (Sco), 
	## Worm ”org.Ce.eg.db” (Worm), Xenopus ”org.Xl.eg.db” (Xl), 
	## Yeast ”org.Sc.sgd.db” (Sc), Zebrafish ”org.Dr.eg.db” (Dr).
	
	# Determine the kind of identifier of the input query genes
	
	## only the gene ID or symbol is needed for enrichment analysis
	# if (ncol(UpGenes) > 1L) UpGenes <- UpGenes[, 1]
	# if (ncol(DnGenes) > 1L) DnGenes <- DnGenes[, 1]
	
	if (is.integer(UpGenes) && is.integer(DnGenes)) {
		identifier <- "geneid"
		bgGenes <- refGenes[, 1]
	} else if (is.character(UpGenes) && is.character(DnGenes)) {
		identifier <- "symbol" 
		bgGenes <- refGenes[, 2]
	} else {
		stop("The input genes should be gene IDs (integer) or gene symbols 
				(character)")
	}
	UpGenes <- intersect(UpGenes, bgGenes)
	DnGenes <- intersect(DnGenes, bgGenes)
	
	# Get general gene pathway (function) annotation and pathway(function) names
	generalAnn <- getGeneralAnnotations(ontology, species, identifier)
	allTermName <- getPathwayNames(ontology)
	annRef <- generalAnn[generalAnn[,1] %in% bgGenes, ]
	
	# Perform enrichment analysis for each drug perturbed gene list that reverses 
	# the input signature
	n <- length(drugs)
	# enrichmentResults <- list(rep(0, n))
	enrichmentResults <- NULL
	for (i in 1:n) {
		drugDEGs <- getDrugSignature(drugs[i], instanceDEGs, productionTreated) 
		## Match gene symbols to geneid if identifier is geneid
		if (identifier == "geneid") {
			drugUpGenes <- as.integer(refGenes[is.element(refGenes[, 2], 
					drugDEGs[[1]]), 1])
			drugDnGenes <- as.integer(refGenes[is.element(refGenes[, 2], 
					drugDEGs[[2]]), 1])
		} else {
			drugUpGenes <- drugDEGs[[1]]
			drugDnGenes <- drugDEGs[[2]]
		}
		reverseUpGenes <- intersect(unique(drugUpGenes), DnGenes)
		reverseDnGenes <- intersect(unique(drugDnGenes), UpGenes)
		if (separate) {
			if (length(reverseUpGenes) > 1) {
			annInterest <- generalAnn[generalAnn[, 1] %in% reverseUpGenes, ]
			dnEnrichments <- enrichment(annInterest, annRef, allTermName, 
						fdrMethod, fdrth)
			} else {
				dnEnrichments <- matrix(0L, 0, 7)
				colnames(dnEnrichments) <- c("id", "name", "refnum", "interestnum", 
						"pvalue", "adjustp", "inputGenes")
			}
			if (length(reverseDnGenes) > 1) {
				annInterest <- generalAnn[generalAnn[, 1] %in% reverseDnGenes, ]
				upEnrichments <- enrichment(annInterest, annRef, allTermName, 
						fdrMethod, fdrth)
			} else {
				upEnrichments <- matrix(0L, 0, 7)
				colnames(upEnrichments) <- c("id", "name", "refnum", "interestnum", 
						"pvalue", "adjustp", "inputGenes")
			}
			upEnrichments <- data.frame(paste(drugs[i], "up", sep = "_"), upEnrichments)
			dnEnrichments <- data.frame(paste(drugs[i], "dn", sep = "_"), dnEnrichments)
			Enrichments <- rbind(upEnrichments, dnEnrichments)
			enrichmentResults <- rbind(enrichmentResults, Enrichments)
			
			# enrichmentResults[[i]] <- list(upEnrichments, dnEnrichments)
		} else {
			if (length(reverseUpGenes) > 1 || length(reverseDnGenes) > 1) {
				interestGenes <- unique(reverseUpGenes, reverseDnGenes)
				annInterest <- generalAnn[generalAnn[, 1] %in% interestGenes, ]
				Enrichments <- enrichment(annInterest, annRef, allTermName, 
										fdrMethod, fdrth)
			} else {
				Enrichments <- matrix(0L, 0, 7)
				colnames(Enrichments) <- c("id", "name", "refnum", "interestnum", 
						"pvalue", "adjustp", "inputGenes")
			}
			Enrichments <- data.frame(drugs[i], Enrichments)
			enrichmentResults <- rbind(enrichmentResults, Enrichments)
			# enrichmentResults[[i]] <- Enrichments
		}
	} # Perform enrichment analysis for each gene list
	# names(enrichmentResults) <- drugs
	colnames(enrichmentResults)[1] <- "Drug"
	enrichmentResults
}
