enrichmentSignificance <-
function(annRef, annInterest, method = "BY", fdrth = 0.05)
{
    allRefnum <- length(unique(annRef[, 1]))
    allInterestnum <- length(unique(annInterest[, 1]))
    
    # allAnnterm <- unique(annRef[, 2])
    # allAnntermL <- length(allAnnterm)

    refCount <- tapply(annRef[, 1],annRef[, 2],length)
    refTerm <- levels(factor(annRef[, 2]))
    refTermCount <- data.frame(id=refTerm,refnum=array(refCount,length(refCount)))
    interestCount <- tapply(annInterest[, 1],annInterest[, 2],length)
    interestTerm <- levels(factor(annInterest[, 2]))
    interestTermCount <- data.frame(id=interestTerm,interestnum=array(interestCount,length(interestCount)))

    ref_interest_TermCount <- refTermCount;
    ref_interest_TermCount$interestnum <- rep(0, length(ref_interest_TermCount$id))
    ref_interest_TermCount[ref_interest_TermCount$id %in% interestTermCount[, 1], 3] <- interestTermCount$interestnum;

    pv <- phyper(ref_interest_TermCount[, 3]-1,allInterestnum,allRefnum-allInterestnum,ref_interest_TermCount[, 2],lower.tail = FALSE)
    ref_interest_TermCount$pvalue <- pv
    ref_interest_TermCount <- ref_interest_TermCount[order(ref_interest_TermCount[, 4]),]
	
	ref_interest_TermCount$population <- allRefnum
	ref_interest_TermCount$allInterestnum <- allInterestnum
	ref_interest_TermCount$foldEnrichment <- (ref_interest_TermCount[, 3] * allRefnum) / (ref_interest_TermCount[, 2] * allInterestnum)

    if (method == "bonferroni"){
        adjustp <- p.adjust(ref_interest_TermCount$pvalue,method ="bonferroni")
        ref_interest_TermCount$adjustp <- adjustp
        sigTerm <- ref_interest_TermCount[ref_interest_TermCount$adjustp <= fdrth,]
    } else if (method == "BH"){
        adjustp <- p.adjust(ref_interest_TermCount$pvalue,method ="BH")
		ref_interest_TermCount$adjustp <- adjustp
        sigTerm <- ref_interest_TermCount[ref_interest_TermCount$adjustp <= fdrth,]
    } else if (method == "BY"){
        adjustp <- p.adjust(ref_interest_TermCount$pvalue,method ="BY")
        ref_interest_TermCount$adjustp <- adjustp
        sigTerm <- ref_interest_TermCount[ref_interest_TermCount$adjustp <= fdrth,]
    } else if (method == "none") {
        ref_interest_TermCount$adjustp <- ref_interest_TermCount$pvalue
        sigTerm <- ref_interest_TermCount[ref_interest_TermCount$adjustp <= fdrth,]
	}
	rownames(sigTerm) <- NULL
	return(list(sigTerm=sigTerm, allTerm=ref_interest_TermCount))
}
