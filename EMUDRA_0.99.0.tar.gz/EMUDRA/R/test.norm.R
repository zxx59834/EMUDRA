test.norm <-
function(Scores) {
	p <- ks.test(Scores, "pnorm", mean(Scores), sd(Scores), exact = FALSE)
	return(p[[2]])
}
