drug.scores <-
function(drugIstances, scoreMat)
{	
	aggDrugScore <- aggregate(scoreMat, list(drugIstances), mean)
	
	colnames(aggDrugScore) <- c("drug", colnames(scoreMat))
	aggDrugScore
}
