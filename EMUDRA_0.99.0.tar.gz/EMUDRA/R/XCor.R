XCor <-
function(XSet, XDis, corrMethod = "pearson") {
	stopifnot(is.vector(XDis), dim(XSet)[1] == length(XDis))
	cor(XSet, XDis, use = "complete.obs", method = corrMethod)
}
