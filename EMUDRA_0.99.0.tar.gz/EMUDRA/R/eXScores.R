eXScores <-
function(logFCMatrix, upGenes, dnGenes) {

# upDnGenes <- extractDEgenes(diff_exp, fc_thresh, adj_pval_thresh)
# upGenes <- upDnGenes[[1]]
# dnGenes <- upDnGenes[[2]]

XSumScores <- XSum(logFCMatrix, upGenes[, 1], dnGenes[, 1])
XCosScores <- XCosine(logFCMatrix, upGenes[, 1:2], dnGenes[, 1:2])
XPearsCorr <- XCorrelation(logFCMatrix, upGenes[, 1:2], dnGenes[, 1:2])
XSpearCorr <- XCorrelation(logFCMatrix, upGenes[, 1:2], dnGenes[, 1:2], "spearman")
cbind(XSumScores, XCosScores, XPearsCorr, XSpearCorr)
}
