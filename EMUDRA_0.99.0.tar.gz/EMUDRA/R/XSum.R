XSum <-
function(logFC_Matrix, upGenes, dnGenes) {
# logFC_Matrix could be extreme or not
	upGeneLogFC <- logFC_Matrix[match(upGenes, rownames(logFC_Matrix), nomatch = 0L), ]
	dnGeneLogFC <- logFC_Matrix[match(dnGenes, rownames(logFC_Matrix), nomatch = 0L), ]
	
	colSums(upGeneLogFC) - colSums(dnGeneLogFC)
}
