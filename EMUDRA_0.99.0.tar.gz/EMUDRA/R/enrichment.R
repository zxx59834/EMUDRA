enrichment <-
function(annInterest, annRef, allTermName, fdrMethod = "BY", fdrth = 0.05, topn = 10)
{
	## Calculating the statistically significant terms for interesting genes
	termInfo <- enrichmentSignificance(annRef, annInterest, fdrMethod, fdrth)
	sigTerm <- termInfo$sigTerm
	allTerm <- termInfo$allTerm
	## Get the top n terms if no term is significant
	if (length(sigTerm$adjustp) < 10L) {
		allTerm <- allTerm[order(allTerm$pvalue), ]
		sigTerm <- allTerm[1:topn, ] 
	}
	## Finding the GO term name for statistically siginificant terms
	sigTermName <- allTermName[allTermName[, 1] %in% sigTerm[, 1], ]
	sigTermName <- sigTermName[order(sigTermName[, 1]), ]
	sigTerm <- sigTerm[order(sigTerm[, 1]), ]
	sigTerm$name <- sigTermName[, 2]
	sigTerm <- sigTerm[, c(1,9,5,2,6,3,7,4,8)]
	## Group the interesting annotation according to pathways
	interestGroup = split(annInterest[, 1], annInterest[, 2])
	interestGroup <- do.call(rbind, lapply(interestGroup, function(x) {
					geneSymbol = x
					paste(geneSymbol,collapse="; ")}))
	sigTerm$inputGenes <- interestGroup[match(sigTerm$id, rownames(interestGroup))]
	
	return(sigTerm[order(sigTerm$pvalue), ])
}
