XCorrelation <-
function(logFC_Matrix, upInputLogFC, dnInputLogFC, corrMethod = "pearson") {
# corrMethod should be "pearson", "spearman" or "kendall"
	CMapGenes <- rownames(logFC_Matrix)
	upInputLogFC <- upInputLogFC[match(CMapGenes, upInputLogFC[, 1], nomatch = 0L), ]
	dnInputLogFC <- dnInputLogFC[match(CMapGenes, dnInputLogFC[, 1], nomatch = 0L), ]
	upGeneLogFC <- logFC_Matrix[match(upInputLogFC[, 1], CMapGenes, nomatch = 0L), ]
	dnGeneLogFC <- logFC_Matrix[match(dnInputLogFC[, 1], CMapGenes, nomatch = 0L), ]
	CMapLogFC <- rbind(upGeneLogFC, dnGeneLogFC)
	
	inputLogFC <- c(upInputLogFC[, 2], dnInputLogFC[, 2])
	XCor(CMapLogFC, inputLogFC, corrMethod)
}
