XCos <-
function(XSet, XDis) {
	stopifnot(is.vector(XDis), dim(XSet)[1] == length(XDis))
	colSums(XSet*XDis)/sqrt(colSums(XSet^2)*sum(XDis^2))
}
