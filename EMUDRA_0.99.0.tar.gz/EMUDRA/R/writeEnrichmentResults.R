writeEnrichmentResults <-
function(enrichmentResults, 
									path = getwd(), separate = FALSE) 
{
	n <- length(enrichmentResults)
	drugNames <- names(enrichmentResults)
	prefix <- deparse(substitute(enrichmentResults))
	for (i in 1:n) {
		if (separate) {
		if (!is.null(enrichmentResults[[i]]) && nrow(enrichmentResults[[i]][[1]]) > 0) {
			filename <- paste(path, "/", drugNames[i], "_", prefix, "_up.csv", 
					sep = "")
			write.csv(enrichmentResults[[i]][[1]], filename, row.names = FALSE)
		}
		if (!is.null(enrichmentResults[[i]]) && nrow(enrichmentResults[[i]][[2]]) > 0) {
			filename <- paste(path, "/", drugNames[i], "_", prefix, "_dn.csv", 
					sep = "")
			write.csv(enrichmentResults[[i]][[2]], filename, row.names = FALSE)
		}
		} else {
			if (!is.null(enrichmentResults[[i]])) {
			filename <- paste(path, "/", drugNames[i], "_", prefix, ".csv", 
					sep = "")
			write.csv(enrichmentResults[[i]], filename, row.names = FALSE)
			}
		}
	}
}
