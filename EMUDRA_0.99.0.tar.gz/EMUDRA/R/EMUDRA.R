EMUDRA <-
function(signature,
				fileName = "EMUDRA", 
				logFCMatrix = NULL, 
				eX500logFC = NULL, 
				EWlogFC = NULL, 
				productionTreated = NULL, 
				instDEgenes = NULL, 
				symbol2Geneid = NULL, 
				instScores = FALSE, 
				CL = "all", 
				n = 20L) 
{	
# n is the number of drugs will be shown in a output figure
	
	upGenes <- signature[signature[, 2] > 0, ]
	dnGenes <- signature[signature[, 2] < 0, ]
	
	# if (is.null(productionTreated)) data("productionTreated") ## load drug treatment information
	# if (is.null(logFCMatrix)) data("logFCMatrix") ## load log fold change of drug induced expression
	# if (is.null(eX500logFC)) data("eX500logFC") ## load logFC matrix of top and bottom genes
	# if (is.null(EWlogFC)) data("EWlogFC") ## load expression weighted logFC matrix
	# if (is.null(instDEgenes)) data("instDEgenes") ## load DE gene lists of CMap instances
	# if (is.null(symbol2Geneid)) data("symbol2Geneid") ## load matched symbol and geneid
	
	RankedDrugs <- EMUDRAscore(upGenes, dnGenes, logFCMatrix, 
					eX500logFC, EWlogFC, productionTreated, 
					instScores = instScores, CL = CL)
	write.csv(RankedDrugs, paste0(fileName, ".csv"), 
			row.names = FALSE)
	plotTopDrugScores(RankedDrugs$Normalized.Score[1:n], 
					RankedDrugs$compound[1:n], 
					figName = fileName)		
	BP_enrich <- reverseGeneEnrichment(upGenes[, 1], dnGenes[, 1], 
						RankedDrugs$compound[1:n], 
						instanceDEGs = instDEgenes, 
						productionTreated, 
						refGenes = symbol2Geneid) 
	list(RankedDrugs, BP_enrich)
}
