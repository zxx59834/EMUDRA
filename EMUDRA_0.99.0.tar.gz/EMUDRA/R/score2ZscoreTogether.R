score2ZscoreTogether <-
function(scoreMatrix) {
# estimate p-values for positive scores and negative scores together.

	if (is.vector(scoreMatrix)) {
		n = 1 
		m = length(scoreMatrix) 
		scoreMatrix <- cbind(scoreMatrix, scoreMatrix)
	} else if (is.matrix(scoreMatrix) || is.data.frame(scoreMatrix)) {
		n = dim(scoreMatrix)[2] 
		m = dim(scoreMatrix)[1]}
	
	zScoreMatrix <- sapply(1:n, function(i) {
		scorei <- scoreMatrix[, i]
		# zScore <- rep(0, m)
		
		if (test.norm(scorei) >= 0.05) {
			zScore <- (scorei - mean(scorei)) / sd(scorei) 
		} else if (test.norm(normS <- excludeOutliers(scorei, 3)) >= 0.05) {#
			zScore <- (scorei - mean(normS)) / sd(normS) 
		} else if (test.norm(normS <- excludeOutliers(scorei)) >= 0.05) {
			zScore <- (scorei - mean(normS)) / sd(normS) 
		} else if(test.norm(normS <- excludeOutliers(scorei, 1)) >= 0.05) {
			zScore <- (scorei - mean(normS)) / sd(normS) 
		} else if(test.norm(normS <- excludeOutliers(scorei, 0.5)) >= 0.05) {
			zScore <- (scorei - mean(normS)) / sd(normS) 
		} else {
			normS <- excludeOutliers(scorei, 3)
			zScore <- (scorei - mean(normS)) / sd(normS) 
			}
		zScore
		})
	zScoreMatrix
}
