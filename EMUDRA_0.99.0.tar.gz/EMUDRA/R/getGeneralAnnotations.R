getGeneralAnnotations <-
function(ontology = "BP", species = "Hs", 
								identifier = "symbol") 
{
	## identifier could be Gene Symbols (symbol, the default) or Entrez Gene IDs 
	## (geneid); ontology could be "BP" for Gene Ontology (GO) Biological Process 
	## (the default), "CC" for GO Cell Component, "MF" for GO Molecular Function, 
	## "KEGG" for KEGG pathway, and "" for all GO terms; 
	##
	
	## Loading the GO annotation package
	if (species == "Sc") organism <- paste("org", species, "sgd.db", sep = ".")
	else if (species == "At") organism <- paste("org", species, "tair.db", sep = ".")
	else organism <- paste("org", species, "eg.db", sep = ".")
	
	# source("https://bioconductor.org/biocLite.R")
	# require(organism, character.only = TRUE) || biocLite(organism)
	## Extracting the gene annotation data
	organism <- strsplit(organism,".db")
	organism <- organism[[1]]
	conn <- get(paste(organism, "_dbconn", sep = ""))()
	
	if (ontology == "all") {ontologyTable <- paste("go", "all", sep = "_")} 
	else if (toupper(ontology) == "KEGG") {ontologyTable <- "kegg"}
	else {ontologyTable <- paste("go", tolower(ontology), "all", sep = "_")}
	
	## Query database through SQL and DBI
	if (identifier == "geneid") {
		if (toupper(ontology) == "KEGG") {
			.sql <- paste("select distinct t1.gene_id,t2.path_id",
					" from genes as t1 inner join ", ontologyTable, 
					" as t2 on t1._id=t2._id",seq="")
		} else {
			.sql <- paste("select distinct t1.gene_id,t2.go_id",
					" from genes as t1 inner join ", ontologyTable, 
					" as t2 on t1._id=t2._id",seq="")
		}
	} else if (identifier == "symbol") {
		if (toupper(ontology) == "KEGG") {
			.sql <- paste("select distinct t1.symbol,t2.path_id",
					" from gene_info as t1 inner join ", ontologyTable, 
					" as t2 on t1._id=t2._id",seq="")
		} else {
			.sql <- paste("select distinct t1.symbol,t2.go_id",
					" from gene_info as t1 inner join ", ontologyTable, 
					" as t2 on t1._id=t2._id",seq="")
		}
	} else {
		stop("The input genes should be gene IDs (integer) or gene symbols 
				(character)")
	}
	dbGetQuery(conn, .sql)
}
