excludeOutliers <-
function(scores, fold = 1.5) {
	qtl <- quantile(scores)
	lqtl <- qtl[2]
	uqtl <- qtl[4]
	QQdiff <- qtl[4] - qtl[2]
	scores <- scores[scores <= uqtl + QQdiff*fold]
	scores[scores >= lqtl - QQdiff*fold]
}
